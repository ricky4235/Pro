num = 10
print(num)
if num >= 10:
    print("數字是10")
