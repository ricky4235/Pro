a = 3
b = 4
print(a == b)  # 相等: 顯示 "False"
print(a != b)  # 不等: 顯示 "True"
print(a > b)   # 大於: 顯示 "False"
print(a >= b)  # 大於等於: 顯示 "False"
print(a < b)   # 小於: 顯示 "True"
print(a <= b)  # 小於等於: 顯示 "True"


