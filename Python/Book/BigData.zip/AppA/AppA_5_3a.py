animals = {"cat", "dog", "pig", "fish"} # 建立集合
for index, animal in enumerate(animals):
    print('#%d: %s' % (index + 1, animal))



