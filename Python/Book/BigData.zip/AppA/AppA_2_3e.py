s = "hello"
print(s.capitalize())  # 第1個字元大寫: 顯示 "Hello"
print(s.upper())       # 全部轉成大寫: 顯示 "HELLO"
print(s.rjust(7))      # 靠右對齊並填入空白字元: 顯示 "  hello"
print(s.center(7))     # 置中顯示並填入空白字元: 顯示 " hello "
print(s.replace('l', 'L'))  # 取代字串: 顯示 "heLLo"
print('  python '.strip())  # 刪除空白字元: 顯示 "python"


