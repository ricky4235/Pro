t = int(input("請輸入氣溫 => "))
if t < 20:
    print("加件外套!")
print("今天氣溫 = " + str(t))


