animals = ['cat', 'dog', 'bat']
for index, animal in enumerate(animals):
    print(index, animal)


