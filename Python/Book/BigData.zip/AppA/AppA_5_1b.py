animals = ['cat', 'dog', 'bat']
for animal in animals:
    print(animal)


