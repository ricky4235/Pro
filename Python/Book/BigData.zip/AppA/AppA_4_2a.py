import random as R

target = R.randint(1, 100)
print("1~100亂數值: " + str(target))

