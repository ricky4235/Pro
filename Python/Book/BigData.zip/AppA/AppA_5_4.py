t = (5, 6, 7, 8)  # 建立元組
print(type(t))    # 顯示 "<class 'tuple'>"
print(t)          # 顯示 "(5, 6, 7, 8)"
print(t[0])       # 顯示 "5"
print(t[1])       # 顯示 "6"
print(t[-1])      # 顯示 "8"
print(t[-2])      # 顯示 "7"
for ele in t:     # 走訪項目
    print(ele, end=" ")  # 顯示 "5, 6, 7, 8"


