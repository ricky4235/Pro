a = True
b = False
print(type(a)) # 顯示 "<class 'bool'>"
print(a and b) # 邏輯AND: 顯示 "False"
print(a or b)  # 邏輯OR: 顯示"True"
print(not a)   # 邏輯NOT: 顯示 "False"


