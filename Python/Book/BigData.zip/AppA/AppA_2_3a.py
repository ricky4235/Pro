y = 2.5
print(type(y)) # 顯示 "<class 'float'>"
print(y, y + 1, y * 2, y ** 2) # 顯示 "2.5 3.5 5.0 6.25"

