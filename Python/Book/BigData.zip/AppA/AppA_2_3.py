x = 5
print(type(x)) # 顯示 "<class 'int'>"
print(x)       # 顯示 "5"
print(x + 1)   # 加法: 顯示 "6"
print(x - 1)   # 減法: 顯示 "4"
print(x * 2)   # 乘法: 顯示 "10"
print(x / 2)   # 除法: 顯示 "2.5"
print(x // 2)  # 整數除法: 顯示 "2"
print(x % 2)   # 餘數: 顯示 "2"
print(x ** 2)  # 指數: 顯示 "25"
x += 1
print(x)  # 顯示 "6"
x *= 2
print(x)  # 顯示 "12"

