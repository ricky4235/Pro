import pandas as pd

df = pd.read_csv("missing_data.csv")
print(df)
df.info()
