import pandas as pd

s = pd.Series([12, 29, 72,4, 8, 10]) 
print(s) 
 