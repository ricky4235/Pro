import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("GSW_players_stats_2017_18.csv")
df_grouped = df.groupby("Pos")
position = df_grouped["Pos"].count()
# 繪出長條圖
plt.bar([1, 2, 3, 4, 5], position)
plt.xticks([1, 2, 3, 4, 5], position.index)
plt.ylabel("Number of People")
plt.xlabel("Position")
plt.title("NBA Golden State Warriors") 
plt.show()
