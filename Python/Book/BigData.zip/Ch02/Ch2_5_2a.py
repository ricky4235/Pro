fp = open("test.txt", "r", encoding="utf8")
str = fp.read()
print("檔案內容:")
print(str)


