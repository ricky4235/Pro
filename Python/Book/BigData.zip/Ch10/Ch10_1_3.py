str1 = 'Hello' 

print(str1[0])   # H
print(str1[1])   # e
print(str1[-1])  # o
print(str1[-2])  # l

