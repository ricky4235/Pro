str1 = "學習Python語言程式設計" 
str2 = 'Hello World!'
ch1 = "A"
name1 = str()
name2 = str("陳會安")

print(str1)
print(str2)
print("ch1 = " + ch1)
print("name1 = " + name1)
print("name2 = " + name2)
