str1 = 'Hello World!' 

print("len(str1) = " + str(len(str1)))
print("max(str1) = '" + max(str1) + "'")
print("min(str1) = '" + min(str1) + "'")
