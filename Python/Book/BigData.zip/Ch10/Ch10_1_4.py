str1 = "This is a book." 
list1 = str1.split()
print(list1)
str2 = "Tom,Bob,Mary,Joe"
list2 = str2.split(",")
print(list2)
str3 = "23\n12\n45\n56"
list3 = str3.splitlines()
print(list3)
str4 = "23\n12\n45\n56"
list4 = str4.split("\n")
print(list4)
