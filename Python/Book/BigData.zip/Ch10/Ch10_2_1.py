str1 = """Python is a programming language that lets you work quickly
and integrate systems more effectively."""

list1 = str1.split()
print(list1)

str2 = ",".join(list1)
print(str2) 
