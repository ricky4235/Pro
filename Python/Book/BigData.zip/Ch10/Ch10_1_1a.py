str3 = 'Hello' 

for e in str3:
    print(e)

