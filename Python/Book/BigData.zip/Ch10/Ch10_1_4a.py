str1 = "-"
list1 = ['This', 'is', 'a', 'book.']
print(str1.join(list1))

